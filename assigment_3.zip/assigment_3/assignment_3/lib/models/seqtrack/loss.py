import torch
import torch.nn as nn

def build_loss(cfg=None):
    return SeqTrackLoss()

class SeqTrackLoss(nn.Module):
    """
    Simple loss function for SeqTrackV2.
    Can be extended to include classification and regression heads if needed.
    """

    def __init__(self):
        super().__init__()
        self.mse = nn.MSELoss()

    def forward(self, pred, target):
        """
        Args:
            pred: Tensor of predictions
            target: Tensor of targets
        Returns:
            loss: scalar tensor
        """
        loss = self.mse(pred, target)
        return {"total_loss": loss}
