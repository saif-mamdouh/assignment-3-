import os
import torch

def save_checkpoint(state, is_best, save_dir, filename="checkpoint.pth.tar"):
    os.makedirs(save_dir, exist_ok=True)
    file_path = os.path.join(save_dir, filename)
    torch.save(state, file_path)
    if is_best:
        best_path = os.path.join(save_dir, "model_best.pth.tar")
        torch.save(state, best_path)

def load_checkpoint(model, optimizer=None, filename="checkpoint.pth.tar", map_location="cpu"):
    if not os.path.isfile(filename):
        print(f"[Warning] No checkpoint found at '{filename}'")
        return None, 0
    checkpoint = torch.load(filename, map_location=map_location)
    model.load_state_dict(checkpoint["state_dict"])
    if optimizer and "optimizer" in checkpoint:
        optimizer.load_state_dict(checkpoint["optimizer"])
    epoch = checkpoint.get("epoch", 0)
    print(f"=> Loaded checkpoint '{filename}' (epoch {epoch})")
    return checkpoint, epoch
